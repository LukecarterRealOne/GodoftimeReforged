package com.godoftime.particle;

import com.godoftime.GodOfTimeMod;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterParticleProvidersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = GodOfTimeMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ModParticleFactories {

    @SubscribeEvent
    public static void registerProviders(RegisterParticleProvidersEvent event) {
        event.registerSpriteSet(ModParticles.ASTRAL_TRAIL.get(), sprites ->
                new AstralSpriteParticle.Factory(sprites, 1.0F, 0.34F, 0.055F, 0.42F, 16));

        event.registerSpriteSet(ModParticles.ASTRAL_BLADE_YELLOW.get(), sprites ->
                new AstralSpriteParticle.Factory(sprites, 1.0F, 0.39F, 0.045F, 0.62F, 12));

        event.registerSpriteSet(ModParticles.ASTRAL_BLADE_BLACK.get(), sprites ->
                new AstralSpriteParticle.Factory(sprites, 0.08F, 0.08F, 0.1F, 0.55F, 10));

        event.registerSpriteSet(ModParticles.VOID_SLASH.get(), sprites ->
                new AstralSpriteParticle.Factory(sprites, 1.0F, 0.64F, 0.18F, 0.95F, 14));

        event.registerSpriteSet(ModParticles.TIME_RIPPLE.get(), sprites ->
                new AstralSpriteParticle.Factory(sprites, 1.0F, 0.49F, 0.12F, 1.05F, 20));
    }
}
