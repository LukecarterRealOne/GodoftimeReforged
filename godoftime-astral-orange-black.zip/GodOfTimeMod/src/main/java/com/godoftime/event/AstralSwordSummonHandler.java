package com.godoftime.event;

import com.godoftime.GodOfTimeMod;
import com.godoftime.capability.CapabilityEvents;
import com.godoftime.capability.ITimeGodData;
import com.godoftime.item.ModItems;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Builds the Astral Sword inside a slowly rotating, translucent white energy cube.
 * The sword appears as a world item only once the 3D particle frame collapses.
 */
@Mod.EventBusSubscriber(modid = GodOfTimeMod.MOD_ID)
public final class AstralSwordSummonHandler {
    private static final int RITUAL_TICKS = 36;
    private static final Map<UUID, Integer> ACTIVE_RITUALS = new ConcurrentHashMap<>();

    private AstralSwordSummonHandler() {}

    public static void begin(ServerPlayer player) {
        ACTIVE_RITUALS.putIfAbsent(player.getUUID(), RITUAL_TICKS);
        player.addEffect(new net.minecraft.world.effect.MobEffectInstance(
                net.minecraft.world.effect.MobEffects.DAMAGE_RESISTANCE, RITUAL_TICKS + 16, 4, false, false));
        player.serverLevel().playSound(null, player.blockPosition(), SoundEvents.BEACON_ACTIVATE,
                SoundSource.PLAYERS, 1.0F, 0.72F);
        player.sendSystemMessage(Component.literal("A translucent white cube begins assembling the Astral Sword..."));
    }

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || !(event.player instanceof ServerPlayer player)) return;
        Integer remainingValue = ACTIVE_RITUALS.get(player.getUUID());
        if (remainingValue == null) return;

        ServerLevel level = player.serverLevel();
        int remaining = remainingValue;
        int elapsed = RITUAL_TICKS - remaining;
        double progress = elapsed / (double) RITUAL_TICKS;
        Vec3 look = player.getLookAngle().normalize();
        Vec3 center = player.position().add(0.0, player.getEyeHeight() * 0.55, 0.0)
                .add(look.scale(1.35));
        double half = 0.36 + (0.31 * progress);
        drawRotatingCube(level, center, half, elapsed * 0.095, elapsed * 0.052);

        if (elapsed % 3 == 0) {
            // Soft, semi-transparent-looking white haze inside the wireframe.
            level.sendParticles(ParticleTypes.CLOUD, center.x, center.y, center.z,
                    3, half * 0.48, half * 0.48, half * 0.48, 0.005);
            level.sendParticles(ParticleTypes.SNOWFLAKE, center.x, center.y, center.z,
                    2, half * 0.4, half * 0.4, half * 0.4, 0.015);
        }

        if (remaining <= 1) {
            level.sendParticles(ParticleTypes.FLASH, center.x, center.y, center.z, 1, 0, 0, 0, 0);
            level.sendParticles(ParticleTypes.END_ROD, center.x, center.y, center.z,
                    36, 0.36, 0.36, 0.36, 0.09);
            level.sendParticles(ParticleTypes.POOF, center.x, center.y, center.z,
                    14, 0.25, 0.25, 0.25, 0.035);
            level.playSound(null, BlockPos.containing(center), SoundEvents.BEACON_POWER_SELECT,
                    SoundSource.PLAYERS, 1.2F, 1.25F);

            ItemStack sword = new ItemStack(ModItems.ASTRAL_SWORD.get());
            ItemEntity materialized = new ItemEntity(level, center.x, center.y, center.z, sword);
            materialized.setPickUpDelay(5);
            materialized.setDeltaMovement(look.scale(0.06).add(0.0, 0.08, 0.0));
            if (!level.addFreshEntity(materialized)) {
                if (!player.getInventory().add(sword)) player.drop(sword, false);
            }

            player.displayClientMessage(Component.literal("THE ASTRAL SWORD HAS MATERIALIZED"), true);
            ACTIVE_RITUALS.remove(player.getUUID());
        } else {
            ACTIVE_RITUALS.put(player.getUUID(), remaining - 1);
        }
    }

    private static void drawRotatingCube(ServerLevel level, Vec3 center, double half,
                                         double yaw, double pitch) {
        double cy = Math.cos(yaw), sy = Math.sin(yaw);
        double cp = Math.cos(pitch), sp = Math.sin(pitch);
        // Three axes, four parallel edges per axis, six samples along each edge.
        for (int axis = 0; axis < 3; axis++) {
            for (int sideA : new int[]{-1, 1}) {
                for (int sideB : new int[]{-1, 1}) {
                    for (int step = 0; step <= 5; step++) {
                        double u = -half + (2.0 * half * step / 5.0);
                        double x, y, z;
                        if (axis == 0) { x = u; y = sideA * half; z = sideB * half; }
                        else if (axis == 1) { x = sideA * half; y = u; z = sideB * half; }
                        else { x = sideA * half; y = sideB * half; z = u; }

                        // Rotate around vertical, then tilt for a more dimensional energy cage.
                        double rx = x * cy - z * sy;
                        double rz = x * sy + z * cy;
                        double ry = y * cp - rz * sp;
                        double rrz = y * sp + rz * cp;
                        level.sendParticles(ParticleTypes.END_ROD,
                                center.x + rx, center.y + ry, center.z + rrz,
                                1, 0, 0, 0, 0);
                    }
                }
            }
        }
    }
}
