package com.godoftime.client;

import com.godoftime.GodOfTimeMod;
import com.godoftime.ability.TimeAbility;
import com.godoftime.ability.TimeMode;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraftforge.client.gui.overlay.IGuiOverlay;

public class ModHudOverlay implements IGuiOverlay {

    public static final ModHudOverlay INSTANCE = new ModHudOverlay();

    @Override
    public void render(net.minecraftforge.client.gui.overlay.ForgeGui gui, GuiGraphics graphics, float partialTick, int screenWidth, int screenHeight) {
        TimeMode mode = ClientHudState.getMode();
        TimeAbility ability = ClientHudState.getAbility();

        String line1 = mode.getDisplayName();
        String line2 = ability.getDisplayName() + "  [R]";

        int color = switch (mode) {
            case YELLOW -> 0xFFFF7A18; // Ember orange
            case GREEN -> 0xFFB8B8B8;  // Obsidian silver/black theme, kept readable
            case BLUE -> 0xFFD64A12;   // Eclipse burnt orange
        };

        int x = 12;
        int y = screenHeight - 42;
        // Clean orange/black HUD plate with a warm accent edge for every mode.
        int left = x - 5;
        int top = y - 5;
        int right = x + 158;
        int bottom = y + 22;
        graphics.fill(left, top, right, bottom, 0xB8090909);
        graphics.fill(left, top, right, top + 1, 0xFFFF7A18);
        graphics.fill(left, bottom - 1, right, bottom, 0xFF59250C);
        graphics.fill(left, top, left + 1, bottom, 0xFFFF7A18);
        graphics.drawString(gui.getFont(), line1, x, y, color, true);
        graphics.drawString(gui.getFont(), line2, x, y + 11, 0xFFF1E5DB, true);
    }
}
