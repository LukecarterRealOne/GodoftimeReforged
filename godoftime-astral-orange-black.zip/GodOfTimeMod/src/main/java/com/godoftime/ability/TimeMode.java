package com.godoftime.ability;

import net.minecraft.ChatFormatting;

/**
 * The three stances of the God of Time.
 * EMBER (stored as YELLOW) = offense / Astral Sword techniques
 * OBSIDIAN (stored as GREEN) = support / restoration / growth
 * ECLIPSE (stored as BLUE) = time & space control
 * The persistent enum IDs remain unchanged for save compatibility.
 */
public enum TimeMode {
    YELLOW(0, "Ember Mode", ChatFormatting.GOLD),
    GREEN(1, "Obsidian Mode", ChatFormatting.DARK_GRAY),
    BLUE(2, "Eclipse Mode", ChatFormatting.GOLD);

    private final int id;
    private final String displayName;
    private final ChatFormatting color;

    TimeMode(int id, String displayName, ChatFormatting color) {
        this.id = id;
        this.displayName = displayName;
        this.color = color;
    }

    public int getId() {
        return id;
    }

    public String getDisplayName() {
        return displayName;
    }

    public ChatFormatting getColor() {
        return color;
    }

    public TimeMode next() {
        return values()[(this.id + 1) % values().length];
    }

    public static TimeMode byId(int id) {
        for (TimeMode m : values()) {
            if (m.id == id) return m;
        }
        return YELLOW;
    }
}
